The following files were generated for 'test02' in directory
/home/yong/Desktop/fpga/gpmc/ipcore_dir/

XCO file generator:
   Generate an XCO file for compatibility with legacy flows.

   * test02.xco

Creates an implementation netlist:
   Creates an implementation netlist for the IP.

   * test02.constraints/test02.ucf
   * test02.constraints/test02.xdc
   * test02.ngc
   * test02.ucf
   * test02.v
   * test02.veo
   * test02.xdc
   * test02_xmdf.tcl

IP Symbol Generator:
   Generate an IP symbol based on the current project options'.

   * test02.asy

SYM file generator:
   Generate a SYM file for compatibility with legacy flows

   * test02.sym

Generate ISE subproject:
   Create an ISE subproject for use when including this core in ISE designs

   * _xmsgs/pn_parser.xmsgs
   * test02.gise
   * test02.xise

Deliver Readme:
   Readme file for the IP.

   * test02_readme.txt

Generate FLIST file:
   Text file listing all of the output files produced when a customized core was
   generated in the CORE Generator.

   * test02_flist.txt

Please see the Xilinx CORE Generator online help for further details on
generated files and how to use them.

